document.getElementById("warning-code").innerHTML =
    "CopyRight Zufar|Z3r0 @2020";