const nama = document.getElementById("name").value;
alert("selamat datang" + nama);