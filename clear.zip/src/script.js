document.getElementById("laki").addEventListener("click", function() {
    alert("anda adalah laki laki");
});

document.getElementById("perempuan").addEventListener("click", function() {
    alert("anda adalah perempuan");
});

document.getElementById("ngoding").addEventListener("click", function() {
    alert("boleh skali kali kita ngoding");
});