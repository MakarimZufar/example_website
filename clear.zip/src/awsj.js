const source = "<!DOCTYPE html> <
    html lang = "en" >

    <
    head >
    <
    meta charset = "UTF-8" / >
    <
    meta name = "viewport"
content = "width=device-width, initial-scale=1.0" / >
    <
    title > Data Kelas < /title> <
    link rel = "stylesheet"
href = "src/style.css" / >
    <
    script src = "https://kit.fontawesome.com/3471311af3.js"
crossorigin = "anonymous" > < /script> <
    /head>

<
body >
    <
    div class = "container" >
    <
    header >
    <
    span class = "1" > < /span> <
    div class = "header-left" >
    <
    h1 > My First Website < /h1> <
    /div> <
    div class = "header-center" >
    <
    p >
    lorem ipum <
    /p> <
    p class = "p2" >
    dolor sih amet. <
    /p> <
    /div> <
    div class = "header-right" >
    <
    a href = "#1" > Home < /a> <
    a href = "#fa" > Contact < /a> <
    a href = "" > Preference < /a> <
    a href = "" > About < /a> <
    /div> <
    div class = "clear" > < /div> <
    /header> <
    div class = "main" >
    <
    div class = "main-left" >
    <
    form action = "src/lanjut.html"
method = "GET" >
    <
    table >
    <
    tr >
    <
    td >
    <
    label
for = "name" > Name: < /label> <
    /td> <
    td >
    <
    input type = "text"
name = "name"
id = "name"
placeholder = "Makarim Zufar Prambudyo" / >
    <
    /td> <
    /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr >
    <
    td >
    <
    label
for = "email" > Email: < /label> <
    /td> <
    td >
    <
    input type = "email"
name = "email"
id = "email"
placeholder = "makarim.zufar@gmail.com" / >
    <
    /td> <
    /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr >
    <
    td >
    <
    label
for = "notelp" > No Telp: < /label> <
    /td> <
    td >
    <
    input type = "text"
name = "notelp"
id = "notelp"
placeholder = "0812-1859-5122" / >
    <
    /td> <
    /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr >
    <
    td >
    <
    p > jenis kelamin: < /p> <
    /td> <
    td collspan = "2" >
    <
    input type = "radio"
name = "jenisKelamin"
id = "laki" / >
    <
    label
for = "laki" > Laki - Laki < /label> <
    input type = "radio"
name = "jenisKelamin"
id = "perempuan" / >
    <
    label
for = "perempuan" > Perempuan < /label> <
    /td> <
    /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr >
    <
    td >
    <
    p > Hobby: < /p> <
    /td> <
    td collspan = "3" >
    <
    input type = "checkbox"
name = "hobby"
id = "ngoding" / >
    <
    label
for = "ngoding" > Ngoding < /label> <
    input type = "checkbox"
name = "hobby"
id = "menyanyi" / >
    <
    label
for = "menyanyi" > Menyanyi < /label> <
    input type = "checkbox"
name = "hobby"
id = "gamming" / >
    <
    label
for = "gamming" > Gamming < /label> <
    /td> <
    /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr >
    <
    td >
    <
    label
for = "ttl" > Tanggal lahir: < /label> <
    /td> <
    td >
    <
    input type = "date"
name = "ttl"
id = "ttl" / >
    <
    /td> <
    /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr > < /tr> <
    tr >
    <
    td colspan = "4" >
    <
    button type = "submit"
class = "kirim" > Kirim!!! < /button> <
    /td> <
    /tr> <
    /table> <
    /form> <
    /div> <
    div class = "main-right" >
    <
    img src = "assets/img/logo kelas.jpg"
alt = "Logo Kelas" / >
    <
    p >
    Lorem ipsum dolor, sit amet consectetur adipisicing elit.Rerum esse deserunt cumque est nesciunt, iste ducimus minus quidem illum totam ullam impedit porro atque distinctio quam perspiciatis eligendi facere!Quo.Nemo, officia cum.Ullam totam aspernatur
iste, sapiente quaerat commodi corrupti eligendi ab dignissimos a natus voluptatum accusantium asperiores incidunt quo repellat reiciendis rerum beatae ? Ducimus corrupti suscipit voluptates sed.Veritatis aliquid incidunt eos eaque
aut.Tempore distinctio iusto minus quo aspernatur atque beatae aliquam deleniti vel itaque quod, illo corrupti facere ipsum iste minima maiores esse sequi numquam possimus.Exercitationem iure, et nulla amet maiores inventore facilis
velit at, recusandae eaque numquam!Dolore eos tempora cumque saepe repellendus vero, commodi magni error aperiam aut animi hic amet natus libero.Recusandae labore soluta maxime eveniet enim, nemo odit facere unde ipsam alias voluptate
sit nam dolorum at explicabo ad.Necessitatibus ad enim dignissimos saepe culpa nihil deleniti aut amet voluptates!Provident, cumque!Reprehenderit distinctio aliquid, praesentium porro reiciendis maiores maxime!Amet, harum est,
    ipsa quia quisquam beatae velit accusantium, officia accusamus iste quam quibusdam debitis in nemo pariatur ea atque!Non saepe porro minima voluptatum unde sapiente ut error, assumenda eius dolorum autem facere cum molestias recusandae
amet doloribus, eaque veniam vel nemo quibusdam provident!In aspernatur sapiente fugiat dolores!
    <
    /p> <
    a href = ""
target = "_blank"
rel = "noopener noreferrer" > Baca Selengkapnya < /a >
    <
    /div> <
    div class = "clear" > < /div> <
    div class = "main-bottom" >
    <
    p > KEPOIN kami di.... < /p> <
    span id = "fa" > < /span> <
    a href = "#" >
    <
    span class = "facebook fa fa-facebook" > Facebook < /span> <
    /a> <
    a href = "#" >
    <
    span class = "twitter fa fa-twitter" > Twitter < /span> <
    /a> <
    br / >
    <
    a href = "#" >
    <
    span class = "google fa fa-google" > Google Plus < /span> <
    /a> <
    /div> <
    /div> <
    footer >
    <
    a href = "https://www.google.com/search?client=opera&q=makarim+zufar&sourceid=opera&ie=UTF-8&oe=UTF-8" >
    <
    span class = "copyright"
id = "warning-code" > CopyRight Zufar | Z3r0 @2020 < /span >
    <
    /a> <
    /footer> <
    /div>

<
script src = "src/acs231.js" > < /script> <
    script src = "src/script.js" > < /script> <
    script src = "src/asw.js" > < /script> <
    /body> <
    /html >"
document.getElementById("agb").innerHTML = source;